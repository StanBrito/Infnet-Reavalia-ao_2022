/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisacad;

import java.util.List;

/**
 *
 * @author Bruno
 */
public class Aluno extends Pessoa {
    


public Aluno(){}

  public Aluno(Long id, String nome, String matricula, List<Curso>curso){
    super(id, nome, matricula, curso);
  }
  
  

    
    public String nome() {
        return getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String matricula() {
        return getMatricula(); 
    }
    
    public String curso() {
        return getCurso(); 
    }

    @Override
    public String toString() {
        return  "Nome: " + getNome() +
                "\nCargo: Aluno" +
                "\nCpf: " + getCpf() +
                "\nMatricula" + getMatricula() +
                "\nLista de cursos: " + getCurso() +
                "\n";
    }

    @Override
    public float calculaSalario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getCurso(String curso) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
  

  

}

