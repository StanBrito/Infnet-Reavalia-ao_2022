/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisacad;

import java.awt.geom.Arc2D;



/**
 *
 * @author Bruno
 */
public class Administrador extends Pessoa{
    
    private String nome;
    private String cpf;
    private Double salario;
    private String matricula;
    private Long id;
public Administrador(){

      
}

  public Administrador(Long id, String nome, String matricula ,String cpf, Double salario){
    setNome(nome);
    setId(id);
    setMatricula(matricula);
    setCpf(cpf);
    setSalario(salario);
  }

    Administrador(String max, String string, String string0, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   public String nome() {
        return getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String matricula() {
        return getMatricula(); 
    }
    
    public Arc2D.Double salario() {
        return getSalario(); 
    }
    
    public String cpf() {
        return getCpf(); 
    }
    @Override
     public float calculaSalario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setSalario(Double salario) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String toString() {
        return  "Nome: " + getNome() +
                "\nCargo: Administrador" +
                "\nSalário: " + getSalario() +
                "\nCpf: " + getCpf() +
                "\nMatricula" + getMatricula() +
                "\n";
    }
  

}

