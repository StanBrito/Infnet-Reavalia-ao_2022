/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisacad;

/**
 *
 * @author Bruno
 */
import java.awt.geom.Arc2D.Double;

public abstract class Pessoa {
    

  private Long id;
  private String nome;
  private Double salario;
  private String cpf;
  private String curso;
  private String matricula;

  public Pessoa(){}

  public Pessoa(Long id, String nome, Double salario, String cpf, String curso, String matricula){
    this.id = id;
    this.nome = nome;
    this.salario = salario;
    this.cpf = cpf;
    this.curso = curso;
    this.matricula = matricula;
  }
  public void setId(Long id){
    this.id = id;
  }
  public long getId(){
    return this.id;
  }
  public void setNome(String nome){
    this.nome = nome;
  }
  public String getNome(){
    return this.nome;
  }

    /**
     *
     * @param salario
     */
    public void setSalario(Double salario){
    this.salario = salario;
  }
  public Double getSalario(){
    return this.salario;
  }
  public void setCurso(String curso){
    this.curso = curso;
  }
  public String getCurso(){
    return this.curso;
  }
  public void setCpf(String cpf){
    this.cpf = cpf;
  }
  public String getCpf(){
    return this.cpf;
  }
  public void setMatricula(String matricula){
    this.matricula = matricula;
  }
  public String getMatricula(){
    return this.matricula;
  }
  @Override
  public String toString(){
    return "O senhor "+getNome()+" recebe este mês o salario de R$"+Float.toString(calculaSalario());
  }
  public abstract float calculaSalario(); 

}

