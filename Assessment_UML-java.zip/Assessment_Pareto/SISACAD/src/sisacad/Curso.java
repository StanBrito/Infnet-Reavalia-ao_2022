/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisacad;

/**
 *
 * @author Bruno
 */
public class Curso implements Comparable<Curso> {
    private String nome;
    private int horas;

    public Curso() {

    }

    public Curso(String nome, int horas) throws HoraInvalidaException {
        this.nome = nome;

        if (horas < 0)
            throw new HoraInvalidaException("A duração do curso não pode ser negativa!");
        else
            this.horas = horas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    @Override
    public int compareTo(Curso outroCurso) {
        int comparacao = getNome().compareTo(outroCurso.getNome());
        if (comparacao < 0) return -1;
        if (comparacao > 0) return 1;
        return 0;
    }
}

