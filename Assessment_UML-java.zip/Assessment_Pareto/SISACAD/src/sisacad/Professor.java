/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sisacad;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.awt.geom.Arc2D;
import java.util.List;

/**
 *
 * @author Bruno
 */
public class Professor  extends Pessoa{
    public Professor(){}

  public Professor(Long id, String nome, String matricula, List<Cursos>cursos,String salario, String cpf){
    super(id, nome, matricula, cursos, salario );
  }

    
    public String nome() {
        return getNome(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public String matricula() {
        return getMatricula(); 
    }
    
    public String cursos() {
        return getCursos(); 
    }
    
     public Arc2D.Double salario() {
        return getSalario(); 
    }
     
     public String cpf() {
        return getCpf(); 
    }

    @Override
    public String toString() {
        return  "\nCargo: Professor" +
                                  "\nSalário: " + getSalario() +
                                  "\nCpf: " + getCpf() +
                                  "\nMatricula" + getMatricula() +
                                  "\nLista de cursos: " + getCursos(getCursos())+
                                  "\n";
    }

    @Override
    public float calculaSalario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
  

  

}



